package page;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class conn {
    static Connection co=null;
    static Statement st=null;
    static int con()
    {
        try {
            Class.forName("org.mysql.jdbc.Driver");
            co=DriverManager.getConnection("jdbc:mysql://localhost:3306/xyz","root","root");
            st=co.createStatement();
        } catch (ClassNotFoundException ex) {
            return -1;
        } catch (SQLException ex) {
            return -2;
        }
        return 0;
    }
    
    public static Statement getst()
    {
        if(st==null)
        {
            int i=con();
            if(i<0)
            {
                return null;
            }
        }
        return st;
    }
    
}
